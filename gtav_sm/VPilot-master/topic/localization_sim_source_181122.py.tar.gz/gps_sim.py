#!/usr/bin/env python

###############################################################################
# Copyright 2017 The Apollo Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
###############################################################################
"""
For GTA5
"""
# import os
import sys
import json
import time
import random
#import Queue

# rospy for the subscriber
import rospy
# from std_msgs.msg import String

# gps
from modules.localization.proto import pose_pb2
#YYZTEST1119
#from multiprocessing import Process, Queue
#from multiprocessing import  Pool

def gps_test(q):
    while (q.empty()):
        #print(q.empty())
        continue
    gps_list = q.get()
    
def gps_list(pose,q): 
    while (q.empty()):
        #print(q.empty())
        continue
    gps_list = q.get()
    #print("gps_list_start:")
    #print(gps_list)


    # PointENU

    pose.position.x = gps_list[0]
    pose.position.y = gps_list[1]
    pose.position.z = gps_list[2]
    '''
    # Quaternion
    pose.orientation.qx = 0.0
    pose.orientation.qy = 0.0
    pose.orientation.qz = 0.0
    pose.orientation.qw = 0.0
'''
    # Point3D
    pose.linear_velocity.x = gps_list[3]
    pose.linear_velocity.y = gps_list[4]
    pose.linear_velocity.z = gps_list[5]

    # Point3D
    pose.linear_acceleration.x = gps_list[6]
    pose.linear_acceleration.y = gps_list[7]
    pose.linear_acceleration.z = gps_list[8]

    # Point3D
    pose.angular_velocity.x = gps_list[9]
    pose.angular_velocity.y = gps_list[10]
    pose.angular_velocity.z = gps_list[11]

    pose.heading = gps_list[12]

    # Point3D
    pose.linear_acceleration_vrf.x = gps_list[13]
    pose.linear_acceleration_vrf.y = gps_list[14]
    pose.linear_acceleration_vrf.z = gps_list[15]
    '''
    # Point3D
    pose.angular_velocity_vrf.x = 0.0
    pose.angular_velocity_vrf.y = 0.0
    pose.angular_velocity_vrf.z = 0.0

    # Point3D
    pose.euler_angles.x = 0.0
    pose.euler_angles.y = 0.0
    pose.euler_angles.z = 0.0
    '''
    return pose



def gnss_simulation(q):
    rospy.init_node("pose_offline",anonymous=True)
    pose_pub = rospy.Publisher(
        "/apollo/localization/pose",pose_pb2.Pose,queue_size=1)
    #generate localization info
    pose = pose_pb2.Pose()

    #send pose to /apollo/localization/pose
    r = rospy.Rate(1)
    while not rospy.is_shutdown():
        #print("gnss_circle")
        pose_pub.publish(gps_list(pose,q))
        #gps_test(q)
        #print("gps_list_end")
        r.sleep()

'''

if __name__ == '__main__':
    manager = multiprocessing.Manager()
    q = manager.Queue()
    p = Pool()
    pw = p.apply_async(write,args=(q,))
    time.sleep(1)
    pr = p.apply_async(read,args=(q,))
    p.close()
    p.join()


	#main()
'''

